package openfalcon

import "fmt"

type CounterType string

const (
	Gauge CounterType = "GAUGE"
)

type Metric struct {
	Metric      string      `json:"metric"`
	Endpoint    string      `json:"endpoint"`
	Timestamp   int64       `json:"timestamp"`
	Step        int32       `json:"step"`
	Value       interface{} `json:"value"`
	CounterType CounterType `json:"counterType"`
	Tags        Tags        `json:"tags,omitempty"`
}

func (m Metric) String() string {
	const endpoint = `__endpoint__`
	t := m.Tags.Clone()
	t[endpoint] = m.Endpoint
	return fmt.Sprintf("%s{%s} %v", m.Metric, t, m.Value)
}
