package openfalcon

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"time"
)

const DefaultAgentURL = `http://127.0.0.1:1988/v1/push`

type Client struct {
	URL  string
	Step int32
	// Hostname string
	client *http.Client
}

func NewClient() *Client {
	client := &http.Client{
		Timeout: 20 * time.Second,
	}
	return &Client{
		URL:  DefaultAgentURL,
		Step: 60,
		// Hostname: hostName,
		client: client,
	}
}

func (c *Client) Push(metrics []Metric) error {
	bs, err := json.Marshal(metrics)
	if err != nil {
		return err
	}
	resp, err := c.client.Post(c.URL, "application/json", bytes.NewBuffer(bs))
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	_, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	return nil
}
