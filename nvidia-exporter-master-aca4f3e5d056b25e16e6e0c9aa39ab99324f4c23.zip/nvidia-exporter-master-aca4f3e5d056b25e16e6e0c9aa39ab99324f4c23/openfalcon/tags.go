package openfalcon

import (
	"encoding/json"
	"sort"
	"strings"
)

type Tags map[string]string

func (ts Tags) Clone() Tags {
	m := make(Tags)
	for k, v := range ts {
		m[k] = v
	}
	return m
}

func (ts Tags) String() string {
	var keys []string
	for k := range ts {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var kv []string
	for _, k := range keys {
		kv = append(kv, k+"="+ts[k])
	}
	return strings.Join(kv, ",")
}

func (ts Tags) MarshalJSON() ([]byte, error) {
	return json.Marshal(ts.String())
}
