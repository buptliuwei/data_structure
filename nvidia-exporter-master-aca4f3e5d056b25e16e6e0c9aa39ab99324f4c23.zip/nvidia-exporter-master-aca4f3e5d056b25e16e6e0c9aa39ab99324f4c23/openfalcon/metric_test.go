package openfalcon

import (
	"encoding/json"
	"fmt"
	"testing"
)

func Test_JSONEncode(t *testing.T) {
	tags := Tags{
		"y": "v2",
		"x": "v1",
	}
	m := Metric{
		Tags: tags,
	}
	bs, err := json.MarshalIndent(m, "", "    ")
	if err != nil {
		t.Error(err)
	}
	fmt.Printf("%s\n", string(bs))
}
