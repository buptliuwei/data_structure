nvidia exporter
======

Exports Nvidia GPU usage of individual containers.



Releases:

* [rpm](http://cnbj1-fds.api.xiaomi.net/nvidia-exporter/release/nvidia-exporter-latest-Linux.rpm)
* [tarball](http://cnbj1-fds.api.xiaomi.net/nvidia-exporter/nvidia-exporter-dist.tar) (no longer maintained, for legacy installation scripts)

