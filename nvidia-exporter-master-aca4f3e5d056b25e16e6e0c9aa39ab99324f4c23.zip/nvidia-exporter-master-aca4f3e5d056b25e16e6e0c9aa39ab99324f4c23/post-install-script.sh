set -ex

chmod +x /usr/bin/nvidia-exporter
