set -e

cd $(dirname $0)
export GOPATH=$(pwd)/.gopath
PKG=$(cat .goimportpath)

mkdir -p $GOPATH/src/$(dirname $PKG)
[ ! -d $GOPATH/src/$PKG ] && ln -s $(pwd) $GOPATH/src/$PKG

go version

go test -v $PKG/nvidiasmi
go test -v $PKG/openfalcon

go install -v $PKG/cmd/nvidia-exporter
