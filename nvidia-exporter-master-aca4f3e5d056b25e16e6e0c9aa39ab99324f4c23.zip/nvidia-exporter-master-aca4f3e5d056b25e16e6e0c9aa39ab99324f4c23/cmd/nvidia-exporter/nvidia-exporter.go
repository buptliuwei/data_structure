package main

import (
	"flag"
	"os"
	"time"

	"github.com/golang/glog"

	"v9.git.n.xiaomi.com/ContainerCloud/nvidia-exporter/dockerutil"
	"v9.git.n.xiaomi.com/ContainerCloud/nvidia-exporter/nvidiasmi"
	"v9.git.n.xiaomi.com/ContainerCloud/nvidia-exporter/openfalcon"
	"v9.git.n.xiaomi.com/ContainerCloud/nvidia-exporter/profile"
)

var (
	period = flag.Duration("period", time.Minute, "duration between each collection")
)

func main() {
	flag.Set("logtostderr", "true")
	flag.Parse()
	glog.CopyStandardLogTo("INFO")
	client := openfalcon.NewClient()
	periodic(*period, func() {
		defer profile.Profile("Report Container GPU Usage").Done()
		metrics, err := collect()
		if err != nil {
			glog.Error(err)
		}
		if err := client.Push(metrics); err != nil {
			glog.Error(err)
		}
	})
}

var hostname, _err = os.Hostname()

func collect() ([]openfalcon.Metric, error) {
	now := time.Now().Unix()
	containerGPUs, err := dockerutil.ListContainerGPUs()
	if err != nil {
		return nil, err
	}
	gpus, err := nvidiasmi.ListGPUs()
	if err != nil {
		return nil, err
	}
	var metrics []openfalcon.Metric
	for _, c := range containerGPUs {
		gpuInfo, ok := gpus[c.GPUName]
		if !ok {
			glog.Error("Invalied GPU Mounted")
			continue
		}
		addPodMetric := func(metric string, val interface{}) openfalcon.Metric {
			return openfalcon.Metric{
				Metric: metric,
				Step:   60,
				Tags: openfalcon.Tags{
					"gpu": gpuInfo.Name,
				},
				Value:       val,
				CounterType: openfalcon.Gauge,
				Endpoint:    c.PodName,
				Timestamp:   now,
			}
		}
		addHostMetric := func(metric string, val interface{}) openfalcon.Metric {
			return openfalcon.Metric{
				Metric: metric,
				Step:   60,
				Tags: openfalcon.Tags{
					"gpu": gpuInfo.Name,
					"pod": c.PodName,
				},
				Value:       val,
				CounterType: openfalcon.Gauge,
				Endpoint:    hostname,
				Timestamp:   now,
			}
		}
		ms := []openfalcon.Metric{
			addPodMetric("container.gpu.util", gpuInfo.Utilization),
			addPodMetric("container.gpu.memutil", gpuInfo.MemoryUtilization),
			addHostMetric("container.gpu.util", gpuInfo.Utilization),
			addHostMetric("container.gpu.memutil", gpuInfo.MemoryUtilization),
		}
		for _, m := range ms {
			glog.Infof("metric: %s", m)
			metrics = append(metrics, m)
		}
	}
	return metrics, nil
}

func periodic(d time.Duration, f func()) {
	f()
	for _ = range time.Tick(d) {
		f()
	}
}
