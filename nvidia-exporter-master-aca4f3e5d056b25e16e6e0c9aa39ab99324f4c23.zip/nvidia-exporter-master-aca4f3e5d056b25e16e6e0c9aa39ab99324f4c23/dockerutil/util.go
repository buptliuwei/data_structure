package dockerutil

import (
	"context"
	"errors"
	"time"

	"github.com/docker/docker/api/types"
	"github.com/docker/docker/client"
	"v9.git.n.xiaomi.com/ContainerCloud/nvidia-exporter/nvidiasmi"
)

type ContainerGPUInfo struct {
	ID       string
	Hostname string
	GPUName  string
	PodName  string
}

func ListContainerGPUs() (map[string]ContainerGPUInfo, error) {
	cli, err := client.NewEnvClient()
	if err != nil {
		return nil, err
	}
	defer cli.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	cli.NegotiateAPIVersion(ctx)
	containers, err := cli.ContainerList(ctx, types.ContainerListOptions{})
	if err != nil {
		return nil, err
	}
	gpuMounts := make(map[string]ContainerGPUInfo)
	for _, c := range containers {
		container, err := cli.ContainerInspect(ctx, c.ID)
		if err != nil {
			return nil, err
		}
		for _, devMap := range container.HostConfig.Devices {
			name, ok := nvidiasmi.ParseGPUName(devMap.PathOnHost)
			if !ok {
				continue
			}
			if _, ok := gpuMounts[name]; ok {
				return nil, errors.New("GPU Mounted to multiple containers")
			}
			gpuMounts[name] = ContainerGPUInfo{
				GPUName:  name,
				ID:       c.ID,
				Hostname: container.Config.Hostname,
				PodName:  container.Config.Labels["io.kubernetes.pod.name"],
			}
		}
	}
	return gpuMounts, nil
}
