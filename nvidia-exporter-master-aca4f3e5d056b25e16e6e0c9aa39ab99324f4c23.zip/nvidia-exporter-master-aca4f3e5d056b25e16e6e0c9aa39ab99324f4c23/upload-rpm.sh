# To install fds CLI, see
# https://github.com/XiaoMi/galaxy-fds-sdk-python

set -e

cd $(dirname $0)/release

for pkg in $(ls *.rpm); do
    echo $pkg
    fds -m put -b nvidia-exporter -d $pkg -o release/$pkg
done
