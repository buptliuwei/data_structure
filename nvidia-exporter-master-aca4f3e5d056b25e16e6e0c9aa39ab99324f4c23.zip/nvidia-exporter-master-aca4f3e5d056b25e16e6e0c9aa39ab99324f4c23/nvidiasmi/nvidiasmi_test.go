package nvidiasmi

import "testing"

func Test_parseGPUInfo(t *testing.T) {
	const output = `
0, 0 %, 30 %
1, 10 %, 0 %
2, 0 %, 0 %
3, 94 %, 59 %
`
	want := []GPUInfo{
		{
			Name:              "nvidia0",
			Utilization:       0,
			MemoryUtilization: 0.3,
		},
		{
			Name:              "nvidia1",
			Utilization:       0.1,
			MemoryUtilization: 0,
		},
		{
			Name:              "nvidia2",
			Utilization:       0,
			MemoryUtilization: 0,
		},
		{
			Name:              "nvidia3",
			Utilization:       0.94,
			MemoryUtilization: 0.59,
		},
	}
	got, err := parseGPUInfo([]byte(output))
	if err != nil {
		t.Error(err)
	}
	if len(got) != len(want) {
		t.Errorf("got %d, want %d", len(got), len(want))
	}
	for i, info := range got {
		if info != want[i] {
			t.Errorf("%#v != %#v", info, want[i])
		}
	}
}

func TestParseGPUName(t *testing.T) {
	tests := []struct {
		DevName string
		GPUName string
		OK      bool
	}{
		{
			DevName: `/dev/nvidia0`,
			GPUName: `nvidia0`,
			OK:      true,
		},
		{
			DevName: `/dev/nvidia4`,
			GPUName: `nvidia4`,
			OK:      true,
		},
		{
			DevName: `/dev/nvidia4x`,
			GPUName: ``,
			OK:      false,
		},
		{
			DevName: `/dev/nvidia`,
			GPUName: ``,
			OK:      false,
		},
		{
			DevName: `/nvidia4`,
			GPUName: ``,
			OK:      false,
		},
	}

	for _, test := range tests {
		if name, ok := ParseGPUName(test.DevName); name != test.GPUName || ok != test.OK {
			t.Errorf("incorrect result of ParseGPUName(%q), want (%s, %v), got (%s, %v)",
				test.DevName, test.GPUName, test.OK, name, ok)
		}
	}
}
