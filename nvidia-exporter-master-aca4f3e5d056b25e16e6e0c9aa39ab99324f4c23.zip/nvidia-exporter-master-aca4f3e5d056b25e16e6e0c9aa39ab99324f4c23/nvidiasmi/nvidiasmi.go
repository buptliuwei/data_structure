package nvidiasmi

import (
	"bytes"
	"encoding/csv"
	"errors"
	"fmt"
	"log"
	"os/exec"
	"strconv"
	"strings"

	"v9.git.n.xiaomi.com/ContainerCloud/nvidia-exporter/profile"
)

type GPUInfo struct {
	Name              string
	Utilization       float32
	MemoryUtilization float32
}

func ListGPUs() (map[string]GPUInfo, error) {
	defer profile.Profile("ListGPUs").Done()
	args := []string{
		`--format=csv,noheader`,
		// see `nvidia-smi --help-query-gpu`
		`--query-gpu=index,utilization.gpu,utilization.memory`,
	}
	cmd := exec.Command("nvidia-smi", args...)
	log.Printf("running: %s", shell(cmd))
	output, err := cmd.CombinedOutput()
	if err != nil {
		return nil, err
	}
	infos, err := parseGPUInfo(output)
	if err != nil {
		return nil, err
	}
	m := make(map[string]GPUInfo)
	for _, info := range infos {
		// FIXME: check unique
		m[info.Name] = info
	}
	return m, nil
}

func parseGPUInfo(output []byte) ([]GPUInfo, error) {
	r := csv.NewReader(bytes.NewBuffer(output))
	records, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	var gpuInfos []GPUInfo
	for _, row := range records {
		if len(row) != 3 {
			return nil, errors.New("Incorrect Number of Columns")
		}
		idx, err := strconv.Atoi(row[0])
		if err != nil {
			return nil, errors.New("Invalid output")
		}
		gpuInfo := GPUInfo{
			Name: "nvidia" + strconv.Itoa(idx),
			// Utilization: x / 100.0,
		}
		if gpuInfo.Utilization, err = parsePercentage(row[1]); err != nil {
			return nil, err
		}
		if gpuInfo.MemoryUtilization, err = parsePercentage(row[2]); err != nil {
			return nil, err
		}
		gpuInfos = append(gpuInfos, gpuInfo)
	}
	return gpuInfos, nil
}

// ParseGPUName extracts the GPU name from dev path if it is an Nvidia GPU
func ParseGPUName(dev string) (string, bool) {
	// /dev/nvidia0 -> nvidia0
	const p = `/dev/nvidia`
	if !strings.HasPrefix(dev, p) {
		return "", false
	}
	idx, err := strconv.Atoi(strings.TrimPrefix(dev, p))
	if err != nil {
		return "", false
	}
	return "nvidia" + strconv.Itoa(idx), true
}

func shell(cmd *exec.Cmd) string {
	return strings.Join(cmd.Args, " ")
}

var errInvalidPercentage = errors.New("Invalid Percentage")

func parsePercentage(val string) (float32, error) {
	var x float32
	if n, err := fmt.Sscanf(val, "%f %%", &x); err != nil || n != 1 {
		return 0, errInvalidPercentage
	}
	return x / 100.0, nil
}
